<?php
       //Récupération de l'image de fond du haut de bas de page
       $chemin = './web/img/font.png';
       $smarty->assign('ImageFond',$chemin);

?>