<?php
       //On crée une variable qui a pour valeur '15'
       $maVariable = 15;
       //On envoie la variable à la vue avec un smarty->assign
       $smarty->assign('nomDeMaVariableSousSmarty', $maVariable);
       
?>