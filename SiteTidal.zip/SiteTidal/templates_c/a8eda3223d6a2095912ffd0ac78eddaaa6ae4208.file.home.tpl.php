<?php /* Smarty version Smarty-3.1.12, created on 2020-10-27 21:48:42
         compiled from "C:\xampp\htdocs\pixyjob\tpl\pages\home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21169277375f9886eb331d63-09600135%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'a8eda3223d6a2095912ffd0ac78eddaaa6ae4208' => 
    array (
      0 => 'C:\\xampp\\htdocs\\pixyjob\\tpl\\pages\\home.tpl',
      1 => 1603831716,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21169277375f9886eb331d63-09600135',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_5f9886eb3669d0_38496819',
  'variables' => 
  array (
    'nomDeMaVariableSousSmarty' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f9886eb3669d0_38496819')) {function content_5f9886eb3669d0_38496819($_smarty_tpl) {?><div>
      Ma variable vaut <?php echo $_smarty_tpl->tpl_vars['nomDeMaVariableSousSmarty']->value;?>

</div><?php }} ?>