<?php /* Smarty version Smarty-3.1.12, created on 2020-10-27 22:39:44
         compiled from "C:\xampp\htdocs\pixyjob\tpl\pages\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:160478915f9888df777296-48106255%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c7213ecb92c5c45c8b96b1c5f630c0436bdb686' => 
    array (
      0 => 'C:\\xampp\\htdocs\\pixyjob\\tpl\\pages\\index.tpl',
      1 => 1603834780,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '160478915f9888df777296-48106255',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_5f9888df7ca899_45507999',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f9888df7ca899_45507999')) {function content_5f9888df7ca899_45507999($_smarty_tpl) {?><div>
      CONTENUE DE LA PAGE
</div><?php }} ?>