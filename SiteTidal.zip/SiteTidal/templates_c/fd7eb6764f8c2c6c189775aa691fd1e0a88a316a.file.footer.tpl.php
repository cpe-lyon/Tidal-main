<?php /* Smarty version Smarty-3.1.12, created on 2020-10-27 22:38:54
         compiled from "C:\xampp\htdocs\pixyjob\tpl\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:10360706275f9886eb37a9b0-75768443%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fd7eb6764f8c2c6c189775aa691fd1e0a88a316a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\pixyjob\\tpl\\footer.tpl',
      1 => 1603834732,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '10360706275f9886eb37a9b0-75768443',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.12',
  'unifunc' => 'content_5f9886eb45e913_01259071',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5f9886eb45e913_01259071')) {function content_5f9886eb45e913_01259071($_smarty_tpl) {?><div>
       <div id="FooterFont">
              <div id="AdressInformation">
                     <p>Adresse</p>
              </div>
              <div id="ContactInformation">
                     <p>Numéro de téléphone et mail</p>
              </div>
              <div id="SocialNetwork">
                     <p>lien facebook</p>
              </div>
       </div>
</div>
</body>
</html><?php }} ?>